<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Usuarios extends BaseController
{
    public function acl() {
        $data['idrol'] = $this->session->idrol;
        $data['id'] = $this->session->id;
        $data['logged'] = $this->usuarioModel->_getLogStatus($data['id']);
        $data['nombre'] = $this->session->nombre;
        $data['miembro_desde'] = $this->session->created_at;
        return $data;
    }

    public function index()
    {
        //
    }

    /**
     * Formulario para registro de un nuevo miembro
     *
     * @param 
     * @return void
     * @throws conditon
     **/
    public function registrarNuevoMiembro() {

        $data['session'] = $this->session;
        $data['sistema'] = $this->sistemaModel->findAll();

        $data['provincias'] = $this->provinciaModel->findAll();
        $data['ciudades'] = $this->ciudadModel->findAll();

        $data['title'] = 'Socios';
        $data['subtitle']='Registro un nuevo Socio';
        $data['main_content'] = 'usuarios/form_reg_new_member';
        return view('dashboard/index', $data);
        
    }

    public function insertNuevoMiembro(){

        $data = $this->acl();

        if ($data['logged'] == 1) {

            $usuario = [
                'nombre' => strtoupper($this->request->getPostGet('nombre')),
                'user' => strtoupper($this->request->getPostGet('user')),
                'password' => strtoupper($this->request->getPostGet('password')),
                'telefono' => strtoupper($this->request->getPostGet('telefono')),
                'telefono_2' => strtoupper($this->request->getPostGet('telefono_2')),
                'cedula' => strtoupper($this->request->getPostGet('cedula')),
                'direccion' => strtoupper($this->request->getPostGet('direccion')),
                'email' => $this->request->getPostGet('email'),
                'idciudad' => strtoupper($this->request->getPostGet('idciudad')),
                'acuerdo_terminos' => strtoupper($this->request->getPostGet('acuerdo_terminos')),
                'estado' => 1,
                'idrol' => 2
            ];
            
            $this->validation->setRuleGroup('insertNewMember');
        
        
            if (!$this->validation->withRequest($this->request)->run()) {
                //Depuración
                //dd($validation->getErrors());
                
                return redirect()->back()->withInput()->with('errors', $this->validation->getErrors());
            }else{ 
                
                //echo '<pre>'.var_export($usuario, true).'</pre>';exit;
                //Inserto el nuevo usuario
                $user = $this->usuarioModel->insert($usuario);

                if ($user) {
                    //Género un codigo de socio
                    $lastId = $this->socioModel->orderBy('id',"desc")->limit(1)->findAll();

                    $socio = [
                        'codigo_socio' => 'GTK-170000'.(int)($lastId[0]->id + 1),
                        'patrocinador' => $this->session->id,
                        'fecha_inscripcion' => date('Y-m-d h:m:s'),
                        'idusuario' => '',
                        'idrango' => '',
                        'estado' => ''
                    ];
                    echo '<pre>'.var_export($socio, true).'</pre>';exit;
                    $this->socioModel->insert($data);
                } else {
                    //Salgo del sistema
                }
                
                echo '<pre>'.var_export($res, true).'</pre>';exit;
                if ($res) {
                    //Se genera un BIR
                     $data = [
                        'idsocio' => $this->session->id,
                        'socio_nuevo' => $res,
                        'fecha' => date('Y-m-d h:m:s'),
                        'estado' => 0,
                    ];
                    $this->birModel->insert();
                }else{

                }
               
                //echo $this->db->getLastQuery();
                return redirect()->to('lista-miembros');
            }
        }else{

            return redirect()->to('logout');
        }
    }

    /**
     * Formulario de edición de datos del socio
     *
     * @param 
     * @return void
     * @throws conditon
     **/
    public function perfil($id, $mensaje = '') {

        $data = $this->acl();
        
        if ($data['logged'] == 1 && $this->session->miembros == 1) {

            $data['session'] = $this->session;
            $data['sistema'] = $this->sistemaModel->findAll();
            $data['provincias'] = $this->provinciaModel->findAll();
            $data['ciudades'] = $this->ciudadModel->findAll();

            $data['perfil'] = $this->usuarioModel->find($id);
            $data['ciudad'] = $this->ciudadModel->where('id', $data['perfil']->idciudad)->find();

            $data['title'] = 'Mis datos';
            $data['subtitle']='Editar datos del usuario';
            $data['mensaje'] = $mensaje;

            if ($data['perfil']) {
                $data['main_content'] = 'usuarios/form_edit_perfil';
            } else {
                $data['main_content'] = 'usuarios/form_error';
            }

            return view('dashboard/index', $data);
        }else{
            return redirect()->to('logout');
        }
        
    }

    /**
     * Recibe la información editada del perfil de un usuario
    */
    public function editProfile($mensaje = ''){

        $data = $this->acl();

        if ($data['logged'] == 1) {

            $id = $this->session->id;

            $usuario = [
                'nombre' => strtoupper($this->request->getPostGet('nombre')),
                'user' => strtoupper($this->request->getPostGet('user')),
                'password' => strtoupper($this->request->getPostGet('password')),
                'telefono' => strtoupper($this->request->getPostGet('telefono')),
                'telefono_2' => strtoupper($this->request->getPostGet('telefono_2')),
                'cedula' => strtoupper($this->request->getPostGet('cedula')),
                'direccion' => strtoupper($this->request->getPostGet('direccion')),
                'email' => $this->request->getPostGet('email'),
                'idciudad' => strtoupper($this->request->getPostGet('idciudad')),
                'acuerdo_terminos' => strtoupper($this->request->getPostGet('acuerdo_terminos')),
            ];
            
            $this->validation->setRuleGroup('insertNewMember');
        
        
            if (!$this->validation->withRequest($this->request)->run()) {
                //Depuración
                //dd($validation->getErrors());
                
                return redirect()->back()->withInput()->with('errors', $this->validation->getErrors());
            }else{ 
                
                //Inserto el nuevo usuario
                $res = $this->usuarioModel->update($id, $usuario);

                if ($res) {
                    $this->session->setFlashdata('mensaje', "success");
                }else{
                    $this->session->setFlashdata('mensaje', "error");
                }
                
                return redirect()->to('perfil/'.$id);
            }
        }else{

            return redirect()->to('logout');
        }
    }

    /**
     * Grid de miembros registrados
     *
     * @param 
     * @return void
     * @throws conditon
     **/
    public function listaMiembros() {

        $data = $this->acl();
        
        if ($data['logged'] == 1 && $this->session->miembros == 1) {

            $data['session'] = $this->session;
            $data['sistema'] = $this->sistemaModel->findAll();

            $data['users'] = $this->usuarioModel->findall();

            $data['title'] = 'Mi Equipo';
            $data['main_content'] = 'usuarios/lista_miembros';
            return view('dashboard/index', $data);
        }else{
            return redirect()->to('logout');
        }
        
    }
}
