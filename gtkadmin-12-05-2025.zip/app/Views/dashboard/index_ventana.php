<?= $this->extend('template/template_ventana'); ?>
<?= $this->section('content'); ?>
    <!-- Main content -->
    <?= $this->include($main_content) ?>
    <!-- /.content -->
<?= $this->endSection(); ?>

