<?php
    echo view('includes/header')
        .view('includes/navbar_login')
        .view($main_content);