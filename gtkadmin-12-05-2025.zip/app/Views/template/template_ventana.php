<?php echo view('includes/header');?>
<body class="">
<div class="content mt-5">
    <?= $this->renderSection('content'); ?>
  </div>
<!-- ./wrapper -->